# Lunapot / Logo varyantları

8 Ekim 2026 · Onaylı V8 geometri

## Kullanım

LOGOLARI-AC.html dosyasını açarak bütün seçenekleri inceleyebilirsin. Çevrimdışı katalog da renk seçimini, SVG ve PNG indirmesini destekler. ZIP içeriğini birlikte bir klasöre çıkart.

- 01-SVG: 32 hazır vektör logo. Büyük baskı, tabela, tasarım ve ölçekleme için ilk tercih. Yazı konturdur; font kurulumu gerekmez.
- 02-PNG: Aynı 32 logonun 1024 / 2048 / 4096 piksel genişlikte 96 şeffaf PNG çıktısı.
- 03-Ozel-Renk: 4 currentColor SVG kaynağı. Katalogdan özel renk seçilerek dışa aktarılır; kendisi varsayılan siyah görünür.
- manifest.json: Dosya listesi ve renkler. AMBLEM-KORUMA.json: değişmez kaynak ve aynı siluet kanıtları.

## Dört kullanım biçimi

**Yatay:** Web başlığı, yatay tabela, evrak ve uzun yüzeyler.
**Dikey:** Amblem üstte, yazı altta; etiket, poşet, kutu kapağı ve ortalanmış sunumlar.
**Yalnız amblem:** Sosyal profil, ürün üzerindeki işaret veya marka bağlamı zaten belli olan alanlar.
**Yalnız yazı:** Dar başlıklar, sade imza ve marka adının öne çıktığı alanlar.

## Renk seçimi

Antrasit ana kullanım, siyah tek renkli baskı, beyaz ve açık renkler koyu zemin içindir. Lime ana vurgu rengidir. Taş/kırık beyaz alternatifleri koyu zeminde görünür. Lime + antrasit ikilisi beyaz/açık zeminde; lime + beyaz koyu zeminde kullanılır. Çift renk lime amblem ile sabit renk yazıdan oluşur. Özel renk aracı sınırsız renk kodu kabul eder; yeni bir ana marka paleti tanımlamaz.

## Logo sabit kalır

Amblem üç orijinal path, marka yazısı yedi orijinal path ile aktarılmıştır. Köşe, açı, iç boşluk, oran, harf şekli ve yerleşim değişmez. Yalnız renk seçilmiş; tüm ölçekler onaylı modülden alınmıştır. Görseller AI ile yeniden üretilmemiştir: onaylı vektörün doğrudan dışa aktarımıdır.

Dosyalar görünür çizime yakın kesilmiştir; dış güvenli alan dosyaya eklenmemiştir. Çevresinde en az amblem yüksekliğinin 1/4'ü, tercihen 1/2'si kadar boşluk bırak. Yatay minimum öneri 140 px / 28 mm; dikey ve yalnız yazı 80 px / 20 mm; amblem 24 px / 6 mm. Bunlar tasarım önerileridir; malzeme ve baskıya göre prova yap.

PNG şeffaftır; önizlemedeki açık/koyu zemin dosyanın parçası değildir. En-boy oranını kilitleyerek boyutlandır. Beyaz logoyu beyaz fonda görememen normaldir. SVG dosyaları RGB/sRGB renktedir; CMYK veya özel mürekkep dönüşümü baskı sağlayıcısında yapılır.
